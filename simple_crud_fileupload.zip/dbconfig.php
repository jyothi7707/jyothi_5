<?php
// error_reporting(0);
// $host = "localhost";
// $user = "root";
// $password = "";
// $datbase = "dbtuts";
// mysqli_connect($host,$user,$password);
// mysqli_select_db($datbase);
?>

<?php
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbtuts";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>