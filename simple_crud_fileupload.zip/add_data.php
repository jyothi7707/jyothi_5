<?php
include_once 'dbconfig.php';
if(isset($_POST['btn-save']))
{
	// variables for input data
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$city_name = $_POST['city_name'];
  $sex=$_POST['sex'];
  $subjectName=$_POST["subject_names"];



// if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"images/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }
  
	// variables for input data
	
	// sql query for inserting data into database
	$sql_query = "INSERT INTO users(first_name,last_name,user_city,dbfile,sex,subject_name) VALUES('$first_name','$last_name','$city_name','$file_name','$sex','$subjectName')";

	// sql query for inserting data into database
	
	// sql query execution function
	if(mysqli_query($conn, $sql_query))
	{
		?>
		<script type="text/javascript">
		alert('Data Are Inserted Successfully ');
		window.location.href='index.php';
		</script>
		<?php
	}
	else
	{
		?>
		<script type="text/javascript">
		alert('error occured while inserting your data');
		</script>
		<?php
	}
	// sql query execution function
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<center>

<div id="header">
	<div id="content">
    
    </div>
</div>
<div id="body">
	<div id="content">
    <form method="post" enctype="multipart/form-data">
    <table align="center">
    <tr>
    <td align="center"><a href="index.php">back to main page</a></td>
    </tr>
    <tr>
    <td><input type="text" name="first_name" placeholder="First Name" required /></td>
    </tr>
    <tr>
    <td><input type="text" name="last_name" placeholder="Last Name" required /></td>
    </tr>
    <tr>
    <td><input type="text" name="city_name" placeholder="City" required /></td>
    </tr>
     <tr>
    <td><input type="file" name="image" placeholder="image" required /></td>
    </tr>
<tr>
  <td><input type="radio" name="sex" value="male"/>Male</td> 
  <td><input type="radio" name="sex" value="female"/>Female</td> 
</tr>
<tr>
  <td>
     <label >Please Select Subject</label>
     <select name="subject_names">
     <option>---Select Subject--</option>
     <option value="Android">Android</option>
     <option value="PHP">PHP</option>
     <option value="Java">Java</option>
     <option value="JavaScript">JavaScript</option>
     <option value="Maths">Maths</option>
 
 </select>
  </td>
</tr>
    <tr>
    <td><button type="submit" name="btn-save"><strong>SAVE</strong></button></td>
    </tr>
    </table>
    </form>
    </div>
</div>

</center>
</body>
</html>