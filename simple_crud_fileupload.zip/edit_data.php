<?php
include_once 'dbconfig.php';
if(isset($_GET['edit_id']))
{
	$sql_query="SELECT * FROM users WHERE user_id=".$_GET['edit_id'];
	$result_set=mysqli_query($conn, $sql_query);
	$fetched_row=mysqli_fetch_array($result_set);
}




if(isset($_POST['btn-update']))
{
	// variables for input data
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$city_name = $_POST['city_name'];
  $sex=$_POST['sex'];
  $extimage=$_POST['extimage'];
  $subject_name=$_POST['subject_names'];
      
     
if(!empty($_FILES['image']['name'])) {

    	$errors= array();
    	 $file_name = $_FILES['image']['name'];
    	  $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"images/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }

}else
{
       $file_name = $_POST['extimage'];
}
  


	// variables for input data
	
	// sql query for update data into database
	$sql_query = "UPDATE users SET first_name='$first_name',last_name='$last_name',user_city='$city_name',dbfile='$file_name', sex='$sex', subject_name='$subject_name' WHERE user_id=".$_GET['edit_id'];
	// sql query for update data into database
	// print_r($sql_query);
	// exit();


	// sql query execution function
	if(mysqli_query($conn, $sql_query))
	{
		?>
		<script type="text/javascript">
		alert('Data Are Updated Successfully');
		window.location.href='index.php';
		</script>
		<?php
	}
	else
	{
		?>
		<script type="text/javascript">
		alert('error occured while updating data');
		</script>
		<?php
	}
	// sql query execution function
}
if(isset($_POST['btn-cancel']))
{
	header("Location: index.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<center>

<div id="header">
	<div id="content">
    <label>CRUD Operations With PHP and MySql - <a href="http://www.codingcage.com" target="_blank">By Coding Cage</a></label>
    </div>
</div>

<div id="body">
	<div id="content">
    <form method="post" enctype="multipart/form-data">
    <table align="center">
    <tr>
    <td><input type="text" name="first_name" placeholder="First Name" value="<?php echo $fetched_row['first_name']; ?>" required /></td>
    </tr>
    <tr>
    <td><input type="text" name="last_name" placeholder="Last Name" value="<?php echo $fetched_row['last_name']; ?>" required /></td>
    </tr>
    <tr>
    <td><input type="text" name="city_name" placeholder="City" value="<?php echo $fetched_row['user_city']; ?>" required /></td>
    </tr>

    <tr>
      <td>
      Male<input value="male"  type="radio" name="sex" <?php if($fetched_row['sex']=="male"){echo "checked";}?>/>
      Female<input <?php if($fetched_row['sex']=="female"){echo "checked";}?> type="radio" name="sex" value="female"/>
      </td>
    </tr>

    <tr>

    <td>
    	<img style="width: 20px;height: 20px" src="images/<?php echo $fetched_row['dbfile']; ?>" >
    	<input type="text" name="extimage" placeholder="extimage" value="<?php echo $fetched_row['dbfile']; ?>" required /></td>
    	<input type="file" name="image" placeholder="newimage"  />
    </td>
    </tr>

    <tr>
  <td>
     <label >Please Select Subject</label>
     <select name="subject_names">
     <option value="Android" <?php if($fetched_row['subject_name']=="Android"){echo 'selected';}?> >Android </option>
     <option value="PHP" <?php if($fetched_row['subject_name']=="PHP"){echo 'selected';}?>>PHP</option>
     <option value="Java" <?php if($fetched_row['subject_name']=="Java"){echo 'selected';}?>>Java</option>
     <option value="JavaScript" <?php if($fetched_row['subject_name']=="JavaScript"){echo 'selected';}?>>JavaScript</option>
     <option value="Maths" <?php if($fetched_row['subject_name']=="Maths"){echo 'selected';}?>>Maths</option>
 
 </select>
  </td>
</tr>


    <tr>
    <td>
    <button type="submit" name="btn-update"><strong>UPDATE</strong></button>
    <button type="submit" name="btn-cancel"><strong>Cancel</strong></button>
    </td>
    </tr>
    </table>
    </form>
    </div>
</div>

</center>
</body>
</html>